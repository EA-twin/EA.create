function sendMessage() {
    var userInput = document.getElementById('userInput').value;
    var chatbox = document.getElementById('chatbox');
    
    // ユーザのメッセージを表示
    chatbox.innerHTML += '<div>User: ' + userInput + '</div>';
    
    // チャットボットの応答を生成
    var botResponse = getBotResponse(userInput);
    
    // チャットボットのメッセージを表示
    chatbox.innerHTML += '<div>Bot: ' + botResponse + '</div>';
    
    // 入力欄をクリア
    document.getElementById('userInput').value = '';
}

function getBotResponse(userInput) {
    // チャットボットの応答ロジックをここに実装
    // 例: ユーザの入力に基づいて適切な応答を返す
    // 例えば、if-else文やswitch文を使って条件に基づいた応答を作成できます。
    
    // ここでは簡単な例として、ユーザの入力をそのまま返す例を示します。
    return userInput;
}
